import { StrictMode } from 'react';
import { createRoot, Root } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

declare global {
  interface Window {
    __reactRoot__?: Root;
  }
}

const container = document.getElementById('root');

if (container) {
  let root = window.__reactRoot__;
  if (!root) {
    root = createRoot(container);
    window.__reactRoot__ = root;
  }

  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}
