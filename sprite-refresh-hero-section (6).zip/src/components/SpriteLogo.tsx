import React from 'react';

const SPRITE_OFFICIAL_LOGO = 'https://res.cloudinary.com/pfjhpymb/image/upload/v1790615840/file_00000000fee082119b29d15bf3b5b131.png';

interface SpriteLogoProps {
  className?: string;
  alt?: string;
}

export const SpriteLogo: React.FC<SpriteLogoProps> = ({
  className = 'h-8 sm:h-9',
  alt = 'Sprite',
}) => {
  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      <img
        src={SPRITE_OFFICIAL_LOGO}
        alt={alt}
        className="h-full w-auto max-h-full object-contain pointer-events-none drop-shadow-[0_2px_10px_rgba(0,0,0,0.18)]"
        crossOrigin="anonymous"
        loading="eager"
      />
    </div>
  );
};
