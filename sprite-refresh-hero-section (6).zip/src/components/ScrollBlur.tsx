import React, { useRef } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'motion/react';

interface ScrollBlurProps {
  children?: React.ReactNode;
  className?: string;
  maxBlur?: number; // Maximum blur in pixels (default: 12)
  maxScale?: number; // Depth scale factor (default: 1.04)
  parallaxOffset?: number; // Vertical parallax displacement (default: 40)
  targetRef?: React.RefObject<HTMLElement | null>;
  scrollProgress?: MotionValue<number>;
  direction?: 'in' | 'out' | 'focus-center'; // How the blur behaves
}

export const ScrollBlur: React.FC<ScrollBlurProps> = ({
  children,
  className = '',
  maxBlur = 10,
  maxScale = 1.03,
  parallaxOffset = 30,
  targetRef,
  scrollProgress,
  direction = 'focus-center',
}) => {
  const localRef = useRef<HTMLDivElement>(null);
  const activeRef = targetRef || localRef;

  const { scrollYProgress: defaultScroll } = useScroll({
    target: activeRef,
    offset: ['start end', 'end start'],
  });

  const progress = scrollProgress || defaultScroll;

  // Compute blur, scale, and y transforms using continuous function maps
  const blurVal = useTransform(progress, (p: number) => {
    if (direction === 'focus-center') {
      if (p <= 0.25) {
        const t = p / 0.25;
        return `blur(${maxBlur * (1 - t) + 2 * t}px)`;
      } else if (p <= 0.5) {
        const t = (p - 0.25) / 0.25;
        return `blur(${2 * (1 - t)}px)`;
      } else if (p <= 0.75) {
        const t = (p - 0.5) / 0.25;
        return `blur(${2 * t}px)`;
      } else {
        const t = (p - 0.75) / 0.25;
        return `blur(${2 * (1 - t) + maxBlur * t}px)`;
      }
    } else if (direction === 'in') {
      if (p <= 0.5) {
        const t = p / 0.5;
        return `blur(${maxBlur * (1 - t)}px)`;
      }
      return 'blur(0px)';
    } else {
      if (p >= 0.5) {
        const t = (p - 0.5) / 0.5;
        return `blur(${maxBlur * t}px)`;
      }
      return 'blur(0px)';
    }
  });

  const scaleVal = useTransform(progress, (p: number) => {
    const minScale = 1 / maxScale;
    if (direction === 'focus-center') {
      if (p <= 0.5) {
        const t = p / 0.5;
        return minScale * (1 - t) + 1 * t;
      } else {
        const t = (p - 0.5) / 0.5;
        return 1 * (1 - t) + maxScale * t;
      }
    } else if (direction === 'in') {
      if (p <= 0.5) {
        const t = p / 0.5;
        return minScale * (1 - t) + 1 * t;
      }
      return 1;
    } else {
      if (p >= 0.5) {
        const t = (p - 0.5) / 0.5;
        return 1 * (1 - t) + maxScale * t;
      }
      return 1;
    }
  });

  const yVal = useTransform(progress, (p: number) => {
    if (direction === 'focus-center') {
      return -parallaxOffset + 2 * parallaxOffset * p;
    } else if (direction === 'in') {
      if (p <= 0.5) {
        return -parallaxOffset * (1 - p / 0.5);
      }
      return 0;
    } else {
      if (p >= 0.5) {
        return parallaxOffset * ((p - 0.5) / 0.5);
      }
      return 0;
    }
  });

  const opacityVal = useTransform(progress, (p: number) => {
    if (direction === 'focus-center') {
      if (p <= 0.15) return 0.6 + (0.4 * p) / 0.15;
      if (p >= 0.85) return 1 - (0.4 * (p - 0.85)) / 0.15;
      return 1;
    } else if (direction === 'in') {
      if (p <= 0.3) return 0.4 + (0.6 * p) / 0.3;
      return 1;
    } else {
      if (p >= 0.7) return 1 - (0.6 * (p - 0.7)) / 0.3;
      return 1;
    }
  });

  return (
    <motion.div
      ref={localRef}
      style={{
        filter: blurVal,
        scale: scaleVal,
        y: yVal,
        opacity: opacityVal,
      }}
      className={`will-change-[filter,transform,opacity] ${className}`}
    >
      {children}
    </motion.div>
  );
};
