import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface SpriteThreeCausticsProps {
  className?: string;
  count?: number;
  interactive?: boolean;
}

export const SpriteThreeCaustics: React.FC<SpriteThreeCausticsProps> = ({
  className = '',
  count = 90,
  interactive = true,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const isVisibleRef = useRef<boolean>(true);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene, Camera, Renderer Setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.z = 18;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(renderer.domElement);

    // 2. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xd8fa00, 2.0);
    dirLight1.position.set(5, 8, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x7cf7b3, 1.8);
    dirLight2.position.set(-5, -6, 3);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0xffffff, 3.5, 30);
    pointLight.position.set(0, 0, 8);
    scene.add(pointLight);

    // 3. Instanced Bubble & Caustic Droplet Spheres
    const sphereGeometry = new THREE.SphereGeometry(0.24, 24, 24);
    const bubbleMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.94,
      opacity: 1,
      transparent: true,
      roughness: 0.05,
      metalness: 0.1,
      ior: 1.33, // Water refractive index
      thickness: 0.5,
      specularIntensity: 1.0,
      specularColor: 0xffffff,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      attenuationColor: 0x98f6ba,
      attenuationDistance: 1.2,
    });

    const instancedMesh = new THREE.InstancedMesh(sphereGeometry, bubbleMaterial, count);
    instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(instancedMesh);

    // Initial Particle State
    const dummy = new THREE.Object3D();
    const particles: Array<{
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      baseScale: number;
      scale: number;
      speed: number;
      wobbleSpeed: number;
      wobbleOffset: number;
    }> = [];

    const spreadX = 22;
    const spreadY = 16;
    const spreadZ = 8;

    for (let i = 0; i < count; i++) {
      const x = (Math.random() - 0.5) * spreadX;
      const y = (Math.random() - 0.5) * spreadY;
      const z = (Math.random() - 0.5) * spreadZ;
      const baseScale = Math.random() * 0.9 + 0.35;

      particles.push({
        x,
        y,
        z,
        vx: (Math.random() - 0.5) * 0.005,
        vy: Math.random() * 0.012 + 0.008, // Upward buoyancy
        vz: (Math.random() - 0.5) * 0.005,
        baseScale,
        scale: baseScale,
        speed: Math.random() * 0.015 + 0.008,
        wobbleSpeed: Math.random() * 2.0 + 1.2,
        wobbleOffset: Math.random() * Math.PI * 2,
      });

      dummy.position.set(x, y, z);
      dummy.scale.set(baseScale, baseScale, baseScale);
      dummy.updateMatrix();
      instancedMesh.setMatrixAt(i, dummy.matrix);
    }
    instancedMesh.instanceMatrix.needsUpdate = true;

    // 4. Mouse Raycasting for Interactive Dispersion
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2(-9999, -9999);
    const targetMouseWorld = new THREE.Vector3();
    const planeZ = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      const rect = container.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      raycaster.ray.intersectPlane(planeZ, targetMouseWorld);
    };

    const onPointerLeave = () => {
      mouse.x = -9999;
      mouse.y = -9999;
    };

    if (interactive) {
      window.addEventListener('mousemove', onPointerMove, { passive: true });
      window.addEventListener('touchmove', onPointerMove, { passive: true });
      window.addEventListener('mouseleave', onPointerLeave);
    }

    // 5. Visibility / IntersectionObserver for zero lag
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          isVisibleRef.current = entry.isIntersecting;
        });
      },
      { threshold: 0.02 }
    );
    observer.observe(container);

    // 6. Responsive Resize Handling
    const handleResize = () => {
      if (!container) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (width === 0 || height === 0) return;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    };
    window.addEventListener('resize', handleResize);

    // 7. Animation Loop with Physics Buoyancy and Surface Reflection
    let animationId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationId = requestAnimationFrame(animate);

      if (!isVisibleRef.current) return;

      const elapsedTime = clock.getElapsedTime();
      const isMouseActive = mouse.x > -900;

      for (let i = 0; i < count; i++) {
        const p = particles[i];

        // Buoyancy drift upward with delicate lateral wave oscillation
        p.y += p.vy;
        p.x += Math.sin(elapsedTime * p.wobbleSpeed + p.wobbleOffset) * 0.008;
        p.z += Math.cos(elapsedTime * p.wobbleSpeed + p.wobbleOffset) * 0.006;

        // Interactive mouse dispersion force
        if (isMouseActive) {
          const dx = p.x - targetMouseWorld.x;
          const dy = p.y - targetMouseWorld.y;
          const distSq = dx * dx + dy * dy;
          const minDist = 4.2;

          if (distSq < minDist * minDist && distSq > 0.001) {
            const dist = Math.sqrt(distSq);
            const force = (minDist - dist) / minDist;
            p.vx += (dx / dist) * force * 0.035;
            p.vy += (dy / dist) * force * 0.035;
          }
        }

        // Apply velocities with damping
        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;
        p.vx *= 0.92;
        p.vz *= 0.92;
        // Keep upward momentum
        p.vy = THREE.MathUtils.lerp(p.vy, p.speed, 0.04);

        // Wrap around viewport boundaries seamlessly
        const halfH = spreadY / 2;
        const halfW = spreadX / 2;
        if (p.y > halfH + 2) {
          p.y = -halfH - 2;
          p.x = (Math.random() - 0.5) * spreadX;
        }
        if (p.x > halfW + 3) p.x = -halfW - 3;
        if (p.x < -halfW - 3) p.x = halfW + 3;

        // Slight breathing scale pulsation
        const pulse = Math.sin(elapsedTime * 2 + i) * 0.05 + 1;
        const currentScale = p.baseScale * pulse;

        dummy.position.set(p.x, p.y, p.z);
        dummy.scale.set(currentScale, currentScale, currentScale);
        dummy.updateMatrix();
        instancedMesh.setMatrixAt(i, dummy.matrix);
      }

      instancedMesh.instanceMatrix.needsUpdate = true;

      // Gentle camera sway for organic fluidity
      camera.position.x = Math.sin(elapsedTime * 0.3) * 0.4;
      camera.position.y = Math.cos(elapsedTime * 0.25) * 0.3;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationId);
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
      if (interactive) {
        window.removeEventListener('mousemove', onPointerMove);
        window.removeEventListener('touchmove', onPointerMove);
        window.removeEventListener('mouseleave', onPointerLeave);
      }
      sphereGeometry.dispose();
      bubbleMaterial.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [count, interactive]);

  return (
    <div
      ref={mountRef}
      className={`absolute inset-0 w-full h-full pointer-events-none z-15 overflow-hidden ${className}`}
    />
  );
};
