import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { spriteAudio } from '../utils/audio';

interface Flip3DTextProps {
  text?: string;
  className?: string;
  onClick?: () => void;
}

export const Flip3DText: React.FC<Flip3DTextProps> = ({
  text = 'FIRE UP',
  className = '',
  onClick,
}) => {
  const [flipKey, setFlipKey] = useState<number>(0);
  const [isHovered, setIsHovered] = useState<boolean>(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    spriteAudio.playCanPop();
    setFlipKey((prev) => prev + 1);
    if (onClick) onClick();
  };

  const characters = Array.from(text);

  return (
    <button
      type="button"
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      aria-label="Click to flip 3D text"
      className={`relative inline-flex items-center justify-center cursor-pointer select-none group outline-none ${className}`}
      style={{ perspective: '1000px' }}
    >
      {/* 3D Staggered Character Flip Container */}
      <span className="inline-flex items-center leading-none" style={{ transformStyle: 'preserve-3d' }}>
        {characters.map((char, index) => {
          if (char === ' ') {
            return (
              <span key={`space-${index}`} className="inline-block w-2.5 sm:w-4">
                &nbsp;
              </span>
            );
          }

          return (
            <span
              key={`${char}-${index}`}
              className="inline-block relative overflow-visible"
              style={{ perspective: '800px', transformStyle: 'preserve-3d' }}
            >
              <motion.span
                key={`${char}-${index}-${flipKey}`}
                initial={flipKey === 0 ? false : { rotateX: -180, opacity: 0.2, y: -8, filter: 'blur(4px)' }}
                animate={{
                  rotateX: 0,
                  opacity: 1,
                  y: 0,
                  filter: 'blur(0px)',
                }}
                whileHover={{
                  y: -3,
                  scale: 1.08,
                  transition: { duration: 0.15 },
                }}
                transition={{
                  duration: 0.75,
                  delay: index * 0.045, // Staggered kinetic flip
                  ease: [0.34, 1.56, 0.64, 1], // Elastic 3D snap
                }}
                style={{
                  display: 'inline-block',
                  transformOrigin: '50% 50% -12px',
                  backfaceVisibility: 'visible',
                  WebkitFontSmoothing: 'antialiased',
                }}
                className="inline-block text-[#003816] select-none will-change-transform"
              >
                {char}
              </motion.span>
            </span>
          );
        })}
      </span>

      {/* Specular Liquid Glint on Flip */}
      <AnimatePresence>
        {flipKey > 0 && (
          <motion.div
            key={`glint-${flipKey}`}
            initial={{ x: '-120%', opacity: 0.9 }}
            animate={{ x: '180%', opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, ease: 'easeInOut' }}
            className="absolute inset-y-0 w-12 bg-gradient-to-r from-transparent via-white/70 to-transparent skew-x-[-25deg] pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* Floating Micro Click Prompt */}
      <div
        className={`absolute -bottom-6 left-1/2 -translate-x-1/2 font-mono text-[9px] uppercase tracking-widest text-[#003816]/70 whitespace-nowrap transition-opacity duration-300 pointer-events-none ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      >
        Click to flip
      </div>
    </button>
  );
};
