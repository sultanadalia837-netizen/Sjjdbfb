import React from 'react';
import { motion } from 'motion/react';

// Delicate, natural soda water bubbles matching reference image flank composition
export const BubbleAtmosphere: React.FC = () => {
  const bubbles = [
    // === RIGHT FLANK (Primary subtle bubble cluster visible in reference image) ===
    { id: 1, x: 1280, y: 380, size: 75, blur: 1.5, opacity: 0.45, delay: 0.2, duration: 8.5, floatY: -35, floatX: -6 },
    { id: 2, x: 1360, y: 440, size: 52, blur: 0.5, opacity: 0.60, delay: 1.2, duration: 7.2, floatY: -28, floatX: 5 },
    { id: 3, x: 1310, y: 520, size: 36, blur: 0, opacity: 0.70, delay: 0.5, duration: 6.8, floatY: -25, floatX: -4 },
    { id: 4, x: 1390, y: 560, size: 68, blur: 1.0, opacity: 0.48, delay: 2.0, duration: 8.0, floatY: -32, floatX: 6 },
    { id: 5, x: 1260, y: 620, size: 28, blur: 0, opacity: 0.75, delay: 0.9, duration: 5.8, floatY: -22, floatX: -3 },
    { id: 6, x: 1340, y: 680, size: 44, blur: 0.5, opacity: 0.58, delay: 1.6, duration: 7.4, floatY: -26, floatX: 4 },
    { id: 7, x: 1380, y: 740, size: 32, blur: 0, opacity: 0.65, delay: 0.4, duration: 6.2, floatY: -20, floatX: -4 },
    { id: 8, x: 1300, y: 800, size: 58, blur: 1.2, opacity: 0.42, delay: 2.4, duration: 8.8, floatY: -30, floatX: 5 },

    // === LEFT FLANK (Subtle balance) ===
    { id: 9, x: 60, y: 480, size: 62, blur: 1.2, opacity: 0.40, delay: 1.0, duration: 8.0, floatY: -28, floatX: 5 },
    { id: 10, x: 120, y: 580, size: 40, blur: 0.5, opacity: 0.55, delay: 0.6, duration: 7.0, floatY: -24, floatX: -4 },
    { id: 11, x: 45, y: 680, size: 50, blur: 0.8, opacity: 0.48, delay: 2.1, duration: 7.6, floatY: -26, floatX: 4 },
    { id: 12, x: 140, y: 760, size: 30, blur: 0, opacity: 0.65, delay: 1.5, duration: 6.0, floatY: -18, floatX: -3 },
  ];

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none z-5 overflow-hidden">
      {bubbles.map((b) => (
        <motion.div
          key={b.id}
          initial={{ y: 0, x: 0, opacity: b.opacity * 0.85 }}
          animate={{
            y: [0, b.floatY, 0],
            x: [0, b.floatX, 0],
            opacity: [b.opacity * 0.85, b.opacity * 1.1, b.opacity * 0.85],
          }}
          transition={{
            duration: b.duration,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: b.delay,
          }}
          className="absolute rounded-full select-none"
          style={{
            left: `${b.x}px`,
            top: `${b.y}px`,
            width: `${b.size}px`,
            height: `${b.size}px`,
            filter: b.blur > 0 ? `blur(${b.blur}px)` : 'none',
            background:
              'radial-gradient(circle at 35% 30%, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.45) 25%, rgba(230, 250, 240, 0.18) 55%, rgba(255, 255, 255, 0.05) 80%, transparent 100%)',
            boxShadow:
              'inset 0 1.5px 3px rgba(255, 255, 255, 0.85), inset 0 -1.5px 3px rgba(0, 50, 30, 0.15), 0 2px 8px rgba(0, 0, 0, 0.04)',
            border: '0.75px solid rgba(255, 255, 255, 0.45)',
          }}
        >
          {/* Specular Glint Dot */}
          <div className="absolute top-[22%] left-[26%] w-[20%] h-[20%] rounded-full bg-white/90 blur-[0.3px]" />
        </motion.div>
      ))}
    </div>
  );
};
