import React, { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface SpriteInteractiveCTAProps {
  onExplore?: () => void;
}

export const SpriteInteractiveCTA: React.FC<SpriteInteractiveCTAProps> = ({ onExplore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext('webgl', { alpha: true, antialias: true });
    if (!gl) return;

    // Sprite themed shader with emerald, lime neon, lemon highlights and fizzy liquid slosh
    const vs = 'attribute vec2 p; void main(){ gl_Position = vec4(p, 0.0, 1.0); }';
    const fs = `
      precision highp float;
      uniform vec2 u_res;
      uniform float u_time, u_level, u_tilt, u_slosh;
      
      float h(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }
      
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p);
        vec2 u = f * f * (3.0 - 2.0 * f);
        return mix(mix(h(i), h(i + vec2(1.0, 0.0)), u.x), mix(h(i + vec2(0.0, 1.0)), h(i + vec2(1.0, 1.0)), u.x), u.y);
      }
      
      float fbm(vec2 p) {
        float v = 0.0; float a = 0.5;
        for(int i = 0; i < 4; i++) {
          v += a * noise(p);
          p = p * 2.04 + vec2(11.3, 7.1);
          a *= 0.5;
        }
        return v;
      }
      
      void main() {
        vec2 uv = gl_FragCoord.xy / u_res;
        float x = uv.x * (u_res.x / u_res.y);
        float t = u_time;
        float amp = 0.015 + u_slosh * 0.055;
        
        // Dynamic water / soda surface with wave oscillation & tilt
        float surf = u_level + u_tilt * (uv.x - 0.5) * 0.38 + amp * sin(x * 5.5 + t * 4.8) + amp * 0.65 * sin(x * 10.2 - t * 7.0 + 1.7);
        float d = surf - uv.y;
        
        // Deep background Sprite forest emerald gradient
        vec3 col = mix(vec3(0.04, 0.22, 0.08), vec3(0.07, 0.34, 0.11), uv.y);
        float inside = smoothstep(0.0, 0.015, d);
        
        // Sprite signature colors: Lime Green (#65C435), Lemon Gold (#FFE500), and Deep Emerald (#0B571B)
        vec3 spriteLime = vec3(0.39, 0.77, 0.21);   // #65C435
        vec3 spriteYellow = vec3(0.98, 0.88, 0.15); // #FFE500
        vec3 spriteDeep = vec3(0.04, 0.34, 0.11);   // #0B571B
        
        vec3 liq = mix(spriteLime, spriteDeep, clamp(d / max(u_level, 0.001), 0.0, 1.0));
        liq = mix(liq, spriteYellow, 0.25 * sin(x * 8.0 + t * 3.0) + 0.25);
        liq *= 0.85 + 0.45 * fbm(vec2(x * 4.5, (uv.y + t * 0.18) * 4.5));
        
        // Add refreshing micro-bubbles / effervescence in the liquid
        float bubbles = step(0.92, noise(vec2(x * 25.0, (uv.y - t * 0.4) * 20.0)));
        liq += vec3(0.6, 1.0, 0.4) * bubbles * inside * 0.4;
        
        col = mix(col, liq, inside);
        
        // Fizzy crest edge glow
        col += vec3(0.85, 1.0, 0.45) * exp(-abs(d) * 65.0) * 0.95;
        
        // Vignette & inner border radiance
        vec2 e = uv * (1.0 - uv);
        col *= 0.65 + 0.35 * pow(e.x * e.y * 16.0, 0.22);
        
        gl_FragColor = vec4(col, 0.92);
      }
    `;

    const createShader = (type: number, src: string) => {
      const s = gl.createShader(type);
      if (!s) return null;
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        gl.deleteShader(s);
        return null;
      }
      return s;
    };

    const vertShader = createShader(gl.VERTEX_SHADER, vs);
    const fragShader = createShader(gl.FRAGMENT_SHADER, fs);
    if (!vertShader || !fragShader) return;

    const prog = gl.createProgram();
    if (!prog) return;

    gl.attachShader(prog, vertShader);
    gl.attachShader(prog, fragShader);
    gl.linkProgram(prog);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      gl.deleteProgram(prog);
      return;
    }

    gl.useProgram(prog);

    const buf = gl.createBuffer();
    if (!buf) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);

    const locP = gl.getAttribLocation(prog, 'p');
    if (locP < 0) return;
    gl.enableVertexAttribArray(locP);
    gl.vertexAttribPointer(locP, 2, gl.FLOAT, false, 0, 0);

    const uRes = gl.getUniformLocation(prog, 'u_res');
    const uTime = gl.getUniformLocation(prog, 'u_time');
    const uLevel = gl.getUniformLocation(prog, 'u_level');
    const uTilt = gl.getUniformLocation(prog, 'u_tilt');
    const uSlosh = gl.getUniformLocation(prog, 'u_slosh');

    let level = 0.58;
    let gulp = 0;
    let slosh = 0.35;
    let tilt = 0;
    let tiltT = 0;
    let lastX: number | null = null;
    let last = 0;
    let animId: number;

    const resize = () => {
      if (!containerRef.current) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.floor(containerRef.current.clientWidth * dpr);
      const h = Math.floor(containerRef.current.clientHeight * dpr);
      if (w > 0 && h > 0 && (canvas.width !== w || canvas.height !== h)) {
        canvas.width = w;
        canvas.height = h;
        gl.viewport(0, 0, w, h);
      }
    };

    const container = containerRef.current;
    if (!container) return;

    const onMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      if (lastX !== null) {
        slosh = Math.min(1.5, slosh + Math.abs(x - lastX) * 2.8);
      }
      lastX = x;
      tiltT = (x - 0.5) * 2.2;
    };

    const onMouseLeave = () => {
      lastX = null;
      tiltT = 0;
    };

    const onClick = () => {
      gulp = 1;
      slosh = Math.min(1.6, slosh + 0.85);
      if (onExplore) onExplore();
    };

    container.addEventListener('mousemove', onMouseMove);
    container.addEventListener('mouseleave', onMouseLeave);
    container.addEventListener('click', onClick);

    const render = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      slosh *= Math.exp(-1.4 * dt);
      gulp *= Math.exp(-1.1 * dt);
      tilt += (tiltT - tilt) * Math.min(1, dt * 5);
      level += (0.58 - 0.36 * gulp - level) * Math.min(1, dt * 5.5);

      resize();
      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform1f(uTime, now / 1000);
      gl.uniform1f(uLevel, level);
      gl.uniform1f(uTilt, tilt);
      gl.uniform1f(uSlosh, slosh);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      container.removeEventListener('mousemove', onMouseMove);
      container.removeEventListener('mouseleave', onMouseLeave);
      container.removeEventListener('click', onClick);
    };
  }, [onExplore]);

  return (
    <div
      ref={containerRef}
      id="nexus-btn"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative flex items-center gap-2 cursor-pointer select-none group"
      style={{
        filter: 'drop-shadow(0 14px 28px rgba(0, 25, 10, 0.65)) drop-shadow(0 4px 10px rgba(0, 0, 0, 0.45)) drop-shadow(0 0 16px rgba(101, 196, 53, 0.25))',
      }}
    >
      {/* SHAPE 1: Left Main Pill ("Explore Sprite") */}
      <motion.div
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
        className="relative overflow-hidden flex items-center justify-center px-7 py-3 rounded-full border border-white/30 backdrop-blur-md transition-all duration-300"
        style={{
          background: 'linear-gradient(135deg, rgba(11, 87, 27, 0.92) 0%, rgba(184, 175, 84, 0.75) 100%)',
          boxShadow: 'inset 0 1px 1px rgba(255, 255, 255, 0.35), inset 0 -1px 2px rgba(0, 0, 0, 0.3)',
        }}
      >
        {/* Interactive WebGL Sprite Liquid Surface Layer */}
        <canvas
          ref={canvasRef}
          aria-hidden="true"
          className="absolute inset-0 w-full h-full block rounded-full opacity-65 pointer-events-none mix-blend-screen"
        />
        {/* Text with Echo styling and subtle glow in Lilita One */}
        <span className="relative z-10 font-lilita font-normal text-[17px] text-white echo-text-cta tracking-wider flex items-center gap-2">
          Explore Sprite
        </span>
        {/* Subtle top light sheen on hover */}
        <div
          className={`absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent rounded-t-full transition-opacity duration-300 pointer-events-none ${
            isHovered ? 'opacity-100' : 'opacity-40'
          }`}
        />
      </motion.div>

      {/* SHAPE 2: Right Arrow Pill / Capsule Shape (Matching reference dual-shape CTA) */}
      <motion.div
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.94 }}
        className="relative overflow-hidden w-12 h-12 rounded-full flex items-center justify-center border border-white/30 backdrop-blur-md transition-all duration-300"
        style={{
          background: 'linear-gradient(135deg, rgba(11, 87, 27, 0.95) 0%, rgba(184, 175, 84, 0.78) 100%)',
          boxShadow: 'inset 0 1px 1px rgba(255, 255, 255, 0.35), inset 0 -1px 2px rgba(0, 0, 0, 0.3)',
        }}
      >
        <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-0.5 transition-transform duration-200" />
        {/* Glow effect on hover */}
        <div
          className={`absolute inset-0 bg-[#65C435]/20 rounded-full transition-opacity duration-300 pointer-events-none ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}
        />
      </motion.div>
    </div>
  );
};
