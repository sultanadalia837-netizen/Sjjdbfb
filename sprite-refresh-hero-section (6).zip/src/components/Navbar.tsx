import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface NavbarProps {
  revealTrigger?: number;
}

type TabType = 'Discover' | 'Flavors' | 'Refresh' | 'Explore';

export const Navbar: React.FC<NavbarProps> = () => {
  const [activeTab, setActiveTab] = useState<TabType>('Discover');

  const navTabs: TabType[] = ['Discover', 'Flavors', 'Refresh', 'Explore'];

  const handleTabClick = (tab: TabType) => {
    setActiveTab(tab);
    spriteAudio.playButtonTap();

    if (tab === 'Flavors') {
      const el = document.getElementById('flavors');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'Refresh' || tab === 'Explore') {
      const aboutEl = document.getElementById('about');
      aboutEl?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header className="absolute top-0 left-0 right-0 z-40 px-12 pt-8 w-full flex items-center justify-between select-none pointer-events-auto">
      {/* Subtle background ambient separation */}
      <div className="absolute inset-x-0 -top-6 h-28 bg-gradient-to-b from-black/[0.05] via-black/[0.015] to-transparent pointer-events-none -z-10 blur-sm" />

      {/* 1. Brand Logo (Left) */}
      <motion.div
        initial={{ y: -25, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
        className="flex items-center"
      >
        <button
          onClick={() => {
            spriteAudio.playButtonTap();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="transition-transform hover:scale-105 active:scale-95 duration-200 cursor-pointer outline-none"
          aria-label="Sprite Home"
        >
          <SpriteLogo className="h-9 sm:h-10 drop-shadow-[0_3px_10px_rgba(0,0,0,0.18)]" />
        </button>
      </motion.div>

      {/* 2. Navigation Items with Light Translucent Capsule Background */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.1, ease: [0.19, 1, 0.22, 1] }}
        className="relative flex items-center justify-center p-1 rounded-full bg-white/[0.08] backdrop-blur-md border border-white/15 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
      >
        <nav className="flex items-center gap-2 sm:gap-4 font-montserrat text-[15px]">
          {navTabs.map((tab) => {
            const isActive = activeTab === tab;
            return (
              <button
                key={tab}
                onClick={() => handleTabClick(tab)}
                onMouseEnter={() => spriteAudio.playButtonHover()}
                className={`relative px-6 py-2 rounded-full cursor-pointer transition-all duration-200 outline-none flex items-center justify-center select-none ${
                  isActive
                    ? 'bg-white/25 text-white font-semibold shadow-[0_4px_14px_rgba(0,35,65,0.18),inset_0_1.5px_2px_rgba(255,255,255,0.7),inset_0_-1px_1.5px_rgba(0,0,0,0.1)] border border-white/35'
                    : 'text-white/90 hover:text-white font-normal hover:bg-white/10'
                }`}
              >
                <span>{tab}</span>

                {/* Vibrant lime/green dot indicator for Refresh */}
                {tab === 'Refresh' && !isActive && (
                  <span className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#82D926] shadow-[0_0_8px_#82D926]" />
                )}
              </button>
            );
          })}
        </nav>
      </motion.div>

      {/* 3. Shop Sprite CTA (Right) */}
      <motion.div
        initial={{ y: -25, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.15, ease: [0.19, 1, 0.22, 1] }}
        className="flex items-center"
      >
        <button
          onClick={() => {
            spriteAudio.playCanPop();
            const el = document.getElementById('flavors');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="group flex items-center gap-2 text-white/95 hover:text-white font-montserrat text-[15px] font-medium transition-transform hover:scale-105 active:scale-95 duration-200 cursor-pointer select-none outline-none drop-shadow-[0_2px_6px_rgba(0,0,0,0.15)]"
        >
          <span>Shop Sprite</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200 text-[#82D926]" />
        </button>
      </motion.div>
    </header>
  );
};
