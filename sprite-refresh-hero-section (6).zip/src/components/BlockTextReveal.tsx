import React from 'react';
import { motion } from 'motion/react';

interface BlockTextRevealProps {
  children: React.ReactNode;
  blockColor?: string; // Unified fresh light color: '#7CF7B3' (Crisp Refresh Mint)
  className?: string;
  delay?: number;
  direction?: 'left-to-right' | 'right-to-left';
}

/**
 * Framer-style one-time scroll reveal combining:
 * 1. Sweeping single-color fresh block wipe
 * 2. Masked kinetic slide-up + unblur typography animation
 * 3. Triggers once on entering viewport (once: true)
 */
export const BlockTextReveal: React.FC<BlockTextRevealProps> = ({
  children,
  blockColor = '#7CF7B3', // Fresh, light crisp street mint
  className = '',
  delay = 0,
  direction = 'left-to-right',
}) => {
  const isLeftToRight = direction === 'left-to-right';

  return (
    <div className={`relative inline-block overflow-hidden py-1 px-1 my-0.5 ${className}`}>
      {/* 1. Sweeping block wipe in fresh light color */}
      <motion.div
        initial={{
          scaleX: 0,
          transformOrigin: isLeftToRight ? '0% 50%' : '100% 50%',
        }}
        whileInView={{
          scaleX: [0, 1, 1, 0],
          transformOrigin: isLeftToRight
            ? ['0% 50%', '0% 50%', '100% 50%', '100% 50%']
            : ['100% 50%', '100% 50%', '0% 50%', '0% 50%'],
        }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{
          duration: 0.95,
          delay,
          ease: [0.77, 0, 0.175, 1],
          times: [0, 0.48, 0.52, 1],
        }}
        style={{ backgroundColor: blockColor }}
        className="absolute inset-0 z-20 pointer-events-none rounded-sm shadow-[0_0_28px_rgba(124,247,179,0.45)]"
      />

      {/* 2. Framer Kinetic Typography Reveal (Rises up from mask, unblurs, rotates into position) */}
      <motion.div
        initial={{
          opacity: 0,
          y: '85%',
          rotateX: 20,
          filter: 'blur(8px)',
        }}
        whileInView={{
          opacity: 1,
          y: '0%',
          rotateX: 0,
          filter: 'blur(0px)',
        }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{
          duration: 0.8,
          delay: delay + 0.38,
          ease: [0.16, 1, 0.3, 1],
        }}
        className="relative z-10 will-change-[transform,opacity,filter]"
      >
        {children}
      </motion.div>
    </div>
  );
};
