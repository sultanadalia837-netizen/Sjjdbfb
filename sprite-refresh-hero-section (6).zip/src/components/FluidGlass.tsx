'use client';

/* eslint-disable react/no-unknown-property */
import * as THREE from 'three';
import React, { useRef, useState, useEffect, memo } from 'react';
import { Canvas, createPortal, useFrame, useThree } from '@react-three/fiber';
import {
  useFBO,
  useScroll,
  Image,
  Scroll,
  Preload,
  ScrollControls,
  MeshTransmissionMaterial,
  Text,
} from '@react-three/drei';
import { easing } from 'maath';

const IMAGE_URLS = [
  'https://images.unsplash.com/photo-1554866585-cd94860890b7?w=900&auto=format&fit=crop&q=60', // Crisp lemon lime soda
  'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=900&auto=format&fit=crop&q=60', // Refreshing soda bubbles
  'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=900&auto=format&fit=crop&q=60', // Ice cold splash
  'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=900&auto=format&fit=crop&q=60', // Citrus slice
  'https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=900&auto=format&fit=crop&q=60', // Water droplets
];

export interface FluidGlassProps {
  mode?: 'lens' | 'bar' | 'cube';
  lensProps?: Record<string, any>;
  barProps?: Record<string, any>;
  cubeProps?: Record<string, any>;
  backgroundColor?: string;
  textColor?: string;
  scale?: number;
  ior?: number;
  className?: string;
  style?: React.CSSProperties;
}

export default function FluidGlass({
  mode = 'lens',
  lensProps = {},
  barProps = {},
  cubeProps = {},
  backgroundColor = 'transparent',
  textColor = '#ffffff',
  scale,
  ior,
  className = '',
  style = {},
}: FluidGlassProps) {
  const Wrapper = mode === 'bar' ? Bar : mode === 'cube' ? Cube : Lens;
  const rawOverrides = mode === 'bar' ? barProps : mode === 'cube' ? cubeProps : lensProps;

  const {
    navItems = [
      { label: 'Discover', link: '#home' },
      { label: 'Manifesto', link: '#about' },
      { label: 'Flavors', link: '#flavors' },
    ],
    ...modeProps
  } = rawOverrides;

  if (scale !== undefined) modeProps.scale = scale;
  if (ior !== undefined) modeProps.ior = ior;

  return (
    <div className={`w-full h-full relative overflow-hidden ${className}`} style={style}>
      <Canvas
        camera={{ position: [0, 0, 20], fov: 15 }}
        gl={{ alpha: true, toneMapping: THREE.NoToneMapping, antialias: true }}
        style={{ background: 'transparent' }}
      >
        <ScrollControls damping={0.2} pages={2} distance={0.3}>
          {mode === 'bar' && <NavItems items={navItems} textColor={textColor} />}
          <Wrapper modeProps={modeProps} backgroundColor={backgroundColor}>
            <Scroll>
              <Typography textColor={textColor} />
              <Images />
            </Scroll>
            <Scroll html />
            <Preload />
          </Wrapper>
        </ScrollControls>
      </Canvas>
    </div>
  );
}

const ModeWrapper = memo(function ModeWrapper({
  children,
  geometryType = 'lens',
  lockToBottom = false,
  followPointer = true,
  modeProps = {},
  backgroundColor = 'transparent',
  ...props
}: {
  children?: React.ReactNode;
  geometryType?: 'lens' | 'bar' | 'cube';
  lockToBottom?: boolean;
  followPointer?: boolean;
  modeProps?: Record<string, any>;
  backgroundColor?: string;
  [key: string]: any;
}) {
  const ref = useRef<THREE.Mesh>(null!);
  const buffer = useFBO();
  const { viewport: vp } = useThree();
  const [scene] = useState(() => new THREE.Scene());

  useFrame((state, delta) => {
    if (!ref.current) return;
    const { gl, viewport, pointer, camera } = state;
    const v = viewport.getCurrentViewport(camera, [0, 0, 15]);

    const destX = followPointer ? (pointer.x * v.width) / 2 : 0;
    const destY = lockToBottom ? -v.height / 2 + 0.3 : followPointer ? (pointer.y * v.height) / 2 : 0;
    easing.damp3(ref.current.position, [destX, destY, 15], 0.15, delta);

    if (modeProps.scale == null) {
      ref.current.scale.setScalar(0.28);
    }

    gl.setClearColor(0x000000, 0);
    gl.setRenderTarget(buffer);
    gl.render(scene, camera);
    gl.setRenderTarget(null);
    gl.setClearColor(0x000000, 0);
  });

  const { scale, ior, thickness, anisotropy, chromaticAberration, ...extraMat } = modeProps;

  return (
    <>
      {createPortal(
        <>
          <mesh position={[0, 0, -5]} scale={[vp.width * 2, vp.height * 2, 1]}>
            <planeGeometry />
            <meshBasicMaterial
              color={backgroundColor === 'transparent' ? '#000000' : backgroundColor}
              transparent={backgroundColor === 'transparent'}
              opacity={backgroundColor === 'transparent' ? 0 : 1}
              toneMapped={false}
            />
          </mesh>
          {children}
        </>,
        scene
      )}
      <mesh scale={[vp.width, vp.height, 1]}>
        <planeGeometry />
        <meshBasicMaterial map={buffer.texture} transparent toneMapped={false} />
      </mesh>
      <mesh
        ref={ref}
        scale={scale ?? 0.28}
        rotation-x={geometryType === 'lens' ? Math.PI / 2 : 0}
        {...props}
      >
        {geometryType === 'lens' ? (
          <cylinderGeometry args={[2.2, 2.2, 0.45, 64]} />
        ) : geometryType === 'bar' ? (
          <boxGeometry args={[4.2, 0.9, 0.35]} />
        ) : (
          <boxGeometry args={[2.0, 2.0, 2.0]} />
        )}
        <MeshTransmissionMaterial
          buffer={buffer.texture}
          ior={ior ?? 1.18}
          thickness={thickness ?? 3.5}
          anisotropy={anisotropy ?? 0.02}
          chromaticAberration={chromaticAberration ?? 0.12}
          roughness={0.04}
          transmission={1}
          distortion={0.2}
          distortionScale={0.3}
          temporalDistortion={0.1}
          color="#ffffff"
          {...extraMat}
        />
      </mesh>
    </>
  );
});

function Lens({ modeProps, ...p }: { modeProps?: Record<string, any>; [key: string]: any }) {
  return <ModeWrapper geometryType="lens" followPointer modeProps={modeProps} {...p} />;
}

function Cube({ modeProps, ...p }: { modeProps?: Record<string, any>; [key: string]: any }) {
  return <ModeWrapper geometryType="cube" followPointer modeProps={modeProps} {...p} />;
}

function Bar({ modeProps = {}, ...p }: { modeProps?: Record<string, any>; [key: string]: any }) {
  const defaultMat = {
    transmission: 1,
    roughness: 0,
    thickness: 6,
    ior: 1.15,
    color: '#ffffff',
    attenuationColor: '#ffffff',
    attenuationDistance: 0.25,
  };

  return (
    <ModeWrapper
      geometryType="bar"
      lockToBottom
      followPointer={false}
      modeProps={{ ...defaultMat, ...modeProps }}
      {...p}
    />
  );
}

type DeviceType = 'mobile' | 'tablet' | 'desktop';

function NavItems({
  items,
  textColor,
}: {
  items: Array<{ label: string; link: string }>;
  textColor: string;
}) {
  const group = useRef<THREE.Group>(null!);
  const { viewport, camera } = useThree();

  const DEVICE: Record<DeviceType, { max: number; spacing: number; fontSize: number }> = {
    mobile: { max: 639, spacing: 0.2, fontSize: 0.035 },
    tablet: { max: 1023, spacing: 0.24, fontSize: 0.035 },
    desktop: { max: Infinity, spacing: 0.3, fontSize: 0.035 },
  };

  const getDevice = (): DeviceType => {
    if (typeof window === 'undefined') return 'desktop';
    const w = window.innerWidth;
    return w <= DEVICE.mobile.max ? 'mobile' : w <= DEVICE.tablet.max ? 'tablet' : 'desktop';
  };

  const [device, setDevice] = useState<DeviceType>(getDevice());

  useEffect(() => {
    const onResize = () => setDevice(getDevice());
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const { spacing, fontSize } = DEVICE[device];

  useFrame(() => {
    if (!group.current) return;
    const v = viewport.getCurrentViewport(camera, [0, 0, 15]);
    group.current.position.set(0, -v.height / 2 + 0.3, 15.1);

    group.current.children.forEach((child, i) => {
      child.position.x = (i - (items.length - 1) / 2) * spacing;
    });
  });

  const handleNavigate = (link: string) => {
    if (!link) return;
    if (link.startsWith('#')) {
      const el = document.querySelector(link);
      el?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.location.href = link;
    }
  };

  return (
    <group ref={group} renderOrder={10}>
      {items.map(({ label, link }) => (
        <Text
          key={label}
          fontSize={fontSize}
          color={textColor}
          anchorX="center"
          anchorY="middle"
          outlineWidth={0}
          outlineBlur={0.2}
          outlineColor="#000000"
          outlineOpacity={0.5}
          renderOrder={10}
          onClick={(e) => {
            e.stopPropagation();
            handleNavigate(link);
          }}
          onPointerOver={() => {
            if (typeof document !== 'undefined') document.body.style.cursor = 'pointer';
          }}
          onPointerOut={() => {
            if (typeof document !== 'undefined') document.body.style.cursor = 'auto';
          }}
        >
          {label}
        </Text>
      ))}
    </group>
  );
}

function Images() {
  const group = useRef<THREE.Group>(null!);
  const data = useScroll();
  const { height } = useThree((s) => s.viewport);

  useFrame(() => {
    if (!group.current) return;
    const ch = group.current.children as any[];
    if (ch[0]?.material) ch[0].material.zoom = 1 + data.range(0, 1 / 3) / 3;
    if (ch[1]?.material) ch[1].material.zoom = 1 + data.range(0, 1 / 3) / 3;
    if (ch[2]?.material) ch[2].material.zoom = 1 + data.range(1.15 / 3, 1 / 3) / 2;
    if (ch[3]?.material) ch[3].material.zoom = 1 + data.range(1.15 / 3, 1 / 3) / 2;
    if (ch[4]?.material) ch[4].material.zoom = 1 + data.range(1.15 / 3, 1 / 3) / 2;
  });

  return (
    <group ref={group}>
      <Image position={[-2.2, 0, 0]} scale={[3, height / 1.1]} url={IMAGE_URLS[0]} />
      <Image position={[2.2, 0, 3]} scale={3} url={IMAGE_URLS[1]} />
      <Image position={[-2.05, -height, 6]} scale={[1.2, 3]} url={IMAGE_URLS[2]} />
      <Image position={[-0.6, -height, 9]} scale={[1.2, 2.2]} url={IMAGE_URLS[3]} />
      <Image position={[0.75, -height, 10.5]} scale={1.8} url={IMAGE_URLS[4]} />
    </group>
  );
}

function Typography({ textColor }: { textColor: string }) {
  const DEVICE: Record<DeviceType, { fontSize: number }> = {
    mobile: { fontSize: 0.22 },
    tablet: { fontSize: 0.42 },
    desktop: { fontSize: 0.62 },
  };

  const getDevice = (): DeviceType => {
    if (typeof window === 'undefined') return 'desktop';
    const w = window.innerWidth;
    return w <= 639 ? 'mobile' : w <= 1023 ? 'tablet' : 'desktop';
  };

  const [device, setDevice] = useState<DeviceType>(getDevice());

  useEffect(() => {
    const onResize = () => setDevice(getDevice());
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const { fontSize } = DEVICE[device];

  return (
    <Text
      position={[0, 0, 12]}
      fontSize={fontSize}
      letterSpacing={-0.03}
      outlineWidth={0}
      outlineBlur={0.2}
      outlineColor="#000000"
      outlineOpacity={0.4}
      color={textColor}
      anchorX="center"
      anchorY="middle"
    >
      SPRITE REFRESH
    </Text>
  );
}
