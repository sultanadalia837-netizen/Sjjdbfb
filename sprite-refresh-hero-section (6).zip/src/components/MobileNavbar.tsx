import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, X } from 'lucide-react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface MobileNavbarProps {
  revealTrigger?: number;
}

export const MobileNavbar: React.FC<MobileNavbarProps> = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'Discover' | 'Flavors' | 'Refresh' | 'Explore'>('Discover');

  const navTabs: Array<'Discover' | 'Flavors' | 'Refresh' | 'Explore'> = [
    'Discover',
    'Flavors',
    'Refresh',
    'Explore',
  ];

  const handleNavClick = (tab: 'Discover' | 'Flavors' | 'Refresh' | 'Explore') => {
    setActiveTab(tab);
    setIsOpen(false);
    spriteAudio.playButtonTap();

    if (tab === 'Flavors') {
      const el = document.getElementById('flavors');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'Refresh' || tab === 'Explore') {
      const el = document.getElementById('about');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const toggleMenu = () => {
    spriteAudio.playButtonTap();
    setIsOpen((prev) => !prev);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-40 px-5 pt-4 pb-3 flex items-center justify-between w-full pointer-events-none">
        {/* Sprite Logo */}
        <div className="relative pointer-events-auto">
          <button
            onClick={() => {
              spriteAudio.playButtonTap();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="transition-transform active:scale-95 duration-200 block cursor-pointer outline-none"
            aria-label="Sprite Home"
          >
            <SpriteLogo className="h-8 drop-shadow-[0_2px_10px_rgba(0,0,0,0.2)]" />
          </button>
        </div>

        {/* Animated Hamburger Button (Hungerbar Menu) */}
        <div className="pointer-events-auto">
          <button
            onClick={toggleMenu}
            className="relative w-11 h-11 rounded-full bg-white/20 backdrop-blur-xl border border-white/40 shadow-[0_4px_16px_rgba(0,0,0,0.15),inset_0_1px_2px_rgba(255,255,255,0.6)] flex items-center justify-center cursor-pointer active:scale-90 transition-transform duration-200 outline-none"
            aria-label={isOpen ? 'Close Menu' : 'Open Menu'}
          >
            <div className="w-5 h-4 flex flex-col justify-between items-center relative">
              <motion.span
                animate={isOpen ? { rotate: 45, y: 7 } : { rotate: 0, y: 0 }}
                transition={{ duration: 0.25, ease: [0.19, 1, 0.22, 1] }}
                className="w-full h-0.5 bg-white rounded-full block origin-center shadow-[0_1px_2px_rgba(0,0,0,0.2)]"
              />
              <motion.span
                animate={isOpen ? { opacity: 0, scaleX: 0 } : { opacity: 1, scaleX: 1 }}
                transition={{ duration: 0.2 }}
                className="w-4 h-0.5 bg-[#82D926] rounded-full block self-start shadow-[0_1px_2px_rgba(0,0,0,0.2)]"
              />
              <motion.span
                animate={isOpen ? { rotate: -45, y: -7 } : { rotate: 0, y: 0 }}
                transition={{ duration: 0.25, ease: [0.19, 1, 0.22, 1] }}
                className="w-full h-0.5 bg-white rounded-full block origin-center shadow-[0_1px_2px_rgba(0,0,0,0.2)]"
              />
            </div>
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.35, ease: [0.19, 1, 0.22, 1] }}
            className="fixed inset-0 z-35 bg-[#003816]/90 backdrop-blur-2xl px-6 pt-24 pb-8 flex flex-col justify-between pointer-events-auto"
          >
            {/* Ambient Background Glow */}
            <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-[#00A850]/30 blur-3xl pointer-events-none" />

            {/* Menu Links */}
            <div className="flex flex-col gap-3 relative z-10">
              <span className="font-mono text-xs uppercase tracking-[0.25em] text-[#82D926] font-bold mb-2">
                Navigation
              </span>

              {navTabs.map((tab, idx) => {
                const isActive = activeTab === tab;
                return (
                  <motion.button
                    key={tab}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 + idx * 0.05, duration: 0.3 }}
                    onClick={() => handleNavClick(tab)}
                    className={`flex items-center justify-between py-3.5 px-5 rounded-2xl text-left font-lilita text-2xl tracking-wide transition-all ${
                      isActive
                        ? 'bg-white/20 text-[#82D926] shadow-[inset_0_1px_1px_rgba(255,255,255,0.4)] border border-white/30'
                        : 'text-white/90 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span>{tab}</span>
                    {isActive && (
                      <span className="w-2 h-2 rounded-full bg-[#82D926] shadow-[0_0_8px_#82D926]" />
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Bottom Shop CTA Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.35 }}
              className="relative z-10 pt-4 border-t border-white/20 flex flex-col gap-3"
            >
              <button
                onClick={() => {
                  setIsOpen(false);
                  spriteAudio.playCanPop();
                  const el = document.getElementById('flavors');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-4 rounded-full bg-gradient-to-r from-[#82D926] via-[#A7F432] to-[#82D926] text-[#003816] font-lilita text-xl tracking-wider shadow-[0_8px_24px_rgba(130,217,38,0.4)] flex items-center justify-center gap-2 active:scale-95 transition-transform"
              >
                <span>Shop Sprite</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
